<div class="card mb-3">
 
  <div class="card-body">
    <h5 class="card-title">List of Campaign</h5>
    
<table class="table">
  <thead class="thead-light">
    <tr>
      <th scope="col">Title</th>
      <th scope="col">First Name</th>
      <th scope="col">Second Name</th>
      <th scope="col">Date of birth</th>
      <th scope="col">Company</th>
      <th scope="col">Operation</th>
    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($campaign->cne); ?></td>
      <td><?php echo e($campaign->firstName); ?></td>
      <td><?php echo e($campaign->secondName); ?></td>
      <td><?php echo e($campaign->dob); ?></td>
      <td><?php echo e($campaign->speciality); ?></td>
      <td>
        
        <a href="<?php echo e(url('/edit/'.$campaign->id)); ?>" class="btn btn-sm btn-warning">Edit</a> <a href="<?php echo e(url('/destroy/'.$campaign->id)); ?>" class="btn btn-sm btn-danger">Delete</a>

      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>


  </div>
</div>




<?php /**PATH C:\xampp\htdocs\camp\resources\views/campaignslist.blade.php ENDPATH**/ ?>